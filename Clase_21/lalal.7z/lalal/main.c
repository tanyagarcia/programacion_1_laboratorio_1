#include <stdio.h>
#include <stdlib.h>
void print(void);
void printSalida(void);
int incrementar(int);

void saludar(void (*s) (void), void (*s1) (void));

int main()
{
    saludar(print, printSalida);

    /*int resultado;

    void (*miPrint) (void);

    int (*funcionIncrementa) (int);

    funcionIncrementa = incrementar;

    miPrint = print;

    miPrint();

    resultado = funcionIncrementa(10);

    printf("El resultado es: %d\n", resultado);

    miPrint = printSalida;

    miPrint();

*/
    return 0;
}

void saludar(void (*s) (void), void (*s1) (void))
{
    s();
    s1();
}


void print()
{
    printf("Hola mundo\n");
}

void printSalida(void)
{
    printf("Chau mundo\n");
}

int incrementar(int x)
{
    x++;
    return x;
}
