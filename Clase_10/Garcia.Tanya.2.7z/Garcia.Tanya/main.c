#include <stdio.h>
#include <stdlib.h>
#include "estacionamiento.h"

#define ALPHA_ROMEO 1
#define FERRARI 2
#define AUDI 3


int main()
{
    eDuenio arrayDuenio[5];
    eEstacionamiento arrayEstacionamiento[5];
    inicializarDuenios(arrayDuenio, 5);

    int opcion=0;
    char seguir='s';

    while(seguir=='s')
    {

        printf("1-ALTA DE DUENIO\n");
        printf("2-MODIFICACION DE DATOS DE DUENIO\n");
        printf("3-INGRESO DE AUTOMOVIL\n");
        printf("4-EGRESO DE AUTOMOVIL\n");
        printf("5-Listado de autos con sus due�os\n");
        printf("6-Propietarios de la marca AUDI\n");
        printf("7-Recaudacion total por marca\n");
        printf("8-Recaudacion total del estacionamiento\n");
        printf("9-SALIR\n");

        printf("Introduzca opcion\n");
        scanf("%d", &opcion);

        switch(opcion)
        {
        case 1:
            cargarDuenios(arrayDuenio, 5);
            break;
        case 2:
            modificarTarjeta(arrayDuenio, 5);
            break;
        case 3:
            cargarAutos(arrayEstacionamiento, 5);
            break;
        case 4:
           egresoDeAuto(arrayEstacionamiento, 5);
            break;
        case 5:
            ordenarEstacionamiento(arrayEstacionamiento, 5);
            break;
        case 6:
            marcaAudi(arrayEstacionamiento, 5);
            break;
        case 7:
            break;
        case 8:
             break;
        case 9:
            seguir='n';
            break;
        default:
            printf("Opcion invalida");
            break;
        }
    }
    return 0;
}
